package thisex;

class BirthDay {
	private int year;
	private int month;
	private int day;
	public void setYear(int year) {
		this.year = year;
	}
}

//public class ThisExample {
//	public static void main(String[] args) {
//		BirthDay bDay = new BirthDay();
//		bDay.setYear(2000);
//		System.out.println(bDay);
//		bDay.printThis();
//	}
//}