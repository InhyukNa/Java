package thisex;

public class PersonTest {

	public static void main(String[] args) {
		
		Person person = new Person();
		person.age = 10;
		person.name = "Karl";
		System.out.println("Person�� Heap �ּ�\n" + person);
		System.out.println(person.returnItSelf());
		
//		Person person2 = person;
//		person.returnItSelf(person2);

	}

}
