package map.treemap;

public class Student {

	private String studentName;
	private String studentID;

	public Student(String studentID, String studentName) {
		this.studentID = studentID;
		this.studentName = studentName;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return Integer.parseInt(studentID);
	}

	@Override
	public boolean equals(Object obj) {
		if(studentID == studentID) {
			return true;
		}
		return false;
	} 

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return studentID + ":" + studentName;
	}
}
