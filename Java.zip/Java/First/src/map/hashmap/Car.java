package map.hashmap;

public class Car {

	String name;
	public Car() {}
	public Car(String name) {
		this.name = name;
	}
}
