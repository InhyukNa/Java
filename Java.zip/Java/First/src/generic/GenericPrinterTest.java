package generic;

import java.util.ArrayList;

public class GenericPrinterTest {

	public static void main(String[] args) {

//		int material1 = 10;
//		double material2 = 20.0;
//		String material3 = "Material";
//		
//		GenericPrinter printer = new GenericPrinter();
//		printer.setMaterial(material1);
//		
//		GenericPrinter printer2 = new GenericPrinter();
//		printer.setMaterial(material2);
//		
//		GenericPrinter printer3 = new GenericPrinter();
//		printer.setMaterial(material3);
//		
//		ArrayList<GenericPrinter> alist = new ArrayList<>();
		
		GenericPrinter<Powder> generic1 = new GenericPrinter<>();
		generic1.setMaterial(new Powder());
		System.out.println(generic1.getMaterial());
		
		GenericPrinter<Plastic> generic2 = new GenericPrinter<>();
		generic2.setMaterial(new Plastic());
		System.out.println(generic2.getMaterial());
		
	}

}
