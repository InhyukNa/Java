package generic;

public class ThreeDPrinter {

	private Object material;
	
	public void seetMaterial(Object material) {
		this.material = material;
	}
}
