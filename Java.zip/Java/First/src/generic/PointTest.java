package generic;

public class PointTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Point<Integer, Double> point = new Point<>(0, 10.0);
		
	}

}
