package reference;

public class Student2 {

	private int studentID;
	private String studentName;
	private int koreaScore;
	private int mathScore;
	private String koreaSubject;
	private String mathSubject;
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getKoreaScore() {
		return koreaScore;
	}
	public void setKoreaScore(int koreaScore) {
		this.koreaScore = koreaScore;
	}
	public int getMathScore() {
		return mathScore;
	}
	public void setMathScore(int mathScore) {
		this.mathScore = mathScore;
	}
	public String getKoreaSubject() {
		return koreaSubject;
	}
	public void setKoreaSubject(String koreaSubject) {
		this.koreaSubject = koreaSubject;
	}
	public String getMathSubject() {
		return mathSubject;
	}
	public void setMathSubject(String mathSubject) {
		this.mathSubject = mathSubject;
	}
	
}
