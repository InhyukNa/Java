package reference;

public class MyDate {

	private int day;
	private int month;
	private int year;
	public boolean isValid;
	
	public MyDate(int day, int month, int year) {
		setYear(year);
		setMonth(month);
		setDay(day);
	}
	
	public int getDay() {
		return day;
	}
	
	public void setDay(int day) {
		
		if (( ( year % 4 ==0 &&  year % 100 !=0 ) || year % 400 ==0)){ 
			if(month == 2) {
				if (day <0 || day >31) {
					isValid = false;
				}
				else {
					this.day = day;
				}
				if (day <0 || day >30) {
					isValid = false;
				}
				else {
					this.day = day;
				}
			}
			
		}
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String isValid() {
		if(isValid) {
			return "��ȿ�� ��¥�Դϴ�.";
		}
		else {
			return "��ȿ���� ���� ��¥�Դϴ�.";
		}
	}
	
}
