package reference;

public class Student3 {

	private int studentID;
	private String sutdentName;
	private Subject korean;
	private Subject math;
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getSutdentName() {
		return sutdentName;
	}
	public void setSutdentName(String sutdentName) {
		this.sutdentName = sutdentName;
	}
	public Subject getKorean() {
		return korean;
	}
	public void setKorean(Subject korean) {
		this.korean = korean;
	}
	public Subject getMath() {
		return math;
	}
	public void setMath(Subject math) {
		this.math = math;
	}
	
}
