package reference;

public class Test {

	public static void main(String[] args) {
		
		Test studentTest = new Test(); 
		
			
			
	

	}

}
