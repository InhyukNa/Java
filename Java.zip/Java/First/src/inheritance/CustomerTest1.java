package inheritance;

public class CustomerTest1 {

	public static void main(String[] args) {

//		VIPCustomer customerNa = new VIPCustomer();
//		customerNa.setCustomerID(10020);
//		customerNa.setCustomerName("������");
//		customerNa.bonusPoint = 10000;
//		System.out.println(customerNa.showCustomerInfo());
//		
//		Customer customerSon = new Customer();
//		customerSon.setCustomerID(10030);
//		customerSon.setCustomerName("�����");
//		customerSon.bonusPoint = 1000;
//		System.out.println(customerSon.showCustomerInfo());
	}

}
