package interfaceex;

public class MyClass implements MyInterface {

	@Override
	public void y() {

		System.out.println("y()");
		
	}

	@Override
	public void x() {
		
		System.out.println("x()");
		
	}

	@Override
	public void myMethod() {
		
		System.out.println("myMethod()");
		
	}

}
