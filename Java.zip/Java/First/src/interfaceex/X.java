package interfaceex;

public interface X {

	void x();
	
}
