package innerclass;

public class OnClickListener {

//	button1.setOnClickListener(new View.OnClickListener()) {
//		public boolean onClick(View v) {
//			Toast.makeText(getBaseContext(), "hello ", Toast.LENGTH_LONG).show();
//			return true;
//		}
//	}a
	
}
