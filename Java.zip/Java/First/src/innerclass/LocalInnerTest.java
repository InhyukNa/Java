package innerclass;

public class LocalInnerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Outer out = new Outer();
		Runnable runner = out.getRunnable(10);
		runner.run();
	}

}
