package exception;

public class ArrayExceptionHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		int[] arr = new int[5];
//		
//		try {
//			for(int i = 0; i <= 5; i++) {
//				arr[i] = i;
//				System.out.println(arr[i]);
//			}
//		} catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println(e);
//			System.out.println("���� ó�� �κ�");
//		}
//		System.out.println("���α׷� ����");
		
		int[] arr2 = {1,2,3,4,5};
		for(int i = 0; i < 6; ++i) {
			try {
				System.out.println(arr2[i]);
				Thread.sleep(1000);
			} catch(InterruptedException e) {
				e.printStackTrace();
			} catch(ArrayIndexOutOfBoundsException ex) {
//				ex.printStackTrace();
				System.out.printf("%s\r\n", "�ε����� �Ѿ��");
			} catch(ArrayStoreException ex) {
				System.out.printf("%s\r\n", "�ε����� �Ѿ��");
			} catch(Exception ex) {
				System.out.printf("%s\r\n", "�ε����� �Ѿ��");
			}
		}
	}

}
