package constructor;

public class Student {
	
	int studentID;
	String studentName;
	long studentNo;
	
	public Student(int studentID) {
		this.studentID = studentID;
	}
	
	public Student(String studentName) {
		this.studentName = studentName;
	}
	
	public Student(long studentNo) {
		this.studentNo = studentNo;
	}
}
