package constructor;

public class StudentTest {

	public static void main(String[] args) {
		
		Student studentNa = new Student("������");
		System.out.println(studentNa.studentName);

	}

}
