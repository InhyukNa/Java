package constructor;

public class PersonTest {

	public static void main(String[] args) {
		
		Person personLee = new Person("Lee", 175, 80);
		System.out.println(personLee.name);
		System.out.println(personLee.weight);
		System.out.println(personLee.height);
		
	}

}
