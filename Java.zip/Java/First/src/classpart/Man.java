package classpart;

public class Man {
	
	int manAge;
	String manName;
	boolean manIsMarried;
	int manCountKids;
	
	public int getManAge() {
		return manAge;
	}
	
	public String getManName() {
		return manName;
	}
	
	public boolean getManIsMarried() {
		return manIsMarried;
	}
	
	public int getManCountKids() {
		return manCountKids;
	}
	
	public void showManInfo() {
		System.out.println(manAge + manName + manIsMarried + manCountKids);
	}
	
	public static void main(String[] args) {
		Man manJames = new Man();
		manJames.manAge = 30;
		manJames.manName = "James";
		manJames.manIsMarried = true;
		manJames.manCountKids = 2;
		
		System.out.println("���� : " + manJames.getManAge());
		System.out.println("�̸� : " + manJames.getManName());
		System.out.println("��ȥ : " + manJames.getManIsMarried());
		System.out.println("�ڳ� : " + manJames.getManCountKids());
		
//		System.out.println(showManInfo());
	}
	


}
