package classpart;

public class StudentTest1 {

	public static void main(String[] args) {
		
		Student student1 = new Student();   // �޸� ���� ���� �߻� (Memory Leak)
		student1.studentName = "�ȿ���";
		System.out.println(student1.getStudentName());
		student1.setStudentID(100);
		System.out.println(student1.getStudentID());
		
		System.out.println("");
		
	    Student student2 = new Student();
	    student2.studentName = "�Ƚ¿�";
	    System.out.println(student2.getStudentName());
//	    student2.setStudentID(200);
	    student2.studentID = 200;
		System.out.println(student2.getStudentID());	    

	}

}
