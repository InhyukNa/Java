package classpart;

public class ShoppingTest {

	public static void main(String[] args) {
		
		Shopping shoppingTest = new Shopping();
		shoppingTest.setOrderNumber(201803120001L);
		shoppingTest.setOrderID("abc123");
		shoppingTest.setOrderDate("2018�� 3�� 12��");
		shoppingTest.setOrderName("ȫ���");
		shoppingTest.setOrderProductName("PD0345-12");
		shoppingTest.setOrderAddress("����� �������� ���ǵ��� 20����");
		
		System.out.println(shoppingTest.getOrderNumber());
		System.out.println(shoppingTest.getOrderID());
		System.out.println(shoppingTest.getOrderDate());
		System.out.println(shoppingTest.getOrderName());
		System.out.println(shoppingTest.getOrderProductName());
		System.out.println(shoppingTest.getOrderAddress());
	}

}
