package classpart;
//import chapter2.Variable1;
public class Student {

	/**
	 *  Data class
	 */
	/**
	 * Instance / Member Variable
	 * ��� ����
	 * ���� ���� -> Ÿ�� �տ� private/public �ٿ��� �� ������ ����
	 */
	
//	Person person;
	
	int studentID;
	String studentName;
	int grade;
	String address;
	// ��� �Լ�
	// Instance �޼ҵ�
	
	public void showStudentInfo() {
		System.out.print(studentName + address);
//		person.gender = 'F';
	}
	
	public String getStudentName() {
		return studentName;
	}
	
	public void setStudentName(String name) {
		studentName = name;
	}
	
	public int getStudentID() {
		return this.studentID;
	}
	
	public void setStudentID(int id) {
		studentID = id;
	}
	
	public static void main(String[] args) {
		Student studentAhn = new Student();
		studentAhn.studentName = "�ȿ���";
				
		System.out.println(studentAhn.studentName);		
		System.out.println(studentAhn.getStudentName());		
	}
}

