package array;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

public class RandomArray {

	public static void main(String[] args) {
		
		int[] lista = new int[10];
		for(int i = 0; i < lista.length; ++i) {
			lista[i] = (int)((Math.random() * 10));
		}
		
		
		ArrayList result = new ArrayList();
		ArrayList list = new ArrayList();
		
		Random rd = new Random();
		
		for(int i = 0; i < 10; i++) {
			int arr = rd.nextInt(10)+1;
			list.add(arr);
		}
//		System.out.println(list);
		
//		System.out.println(list.get(0));
		
		ArrayList list2 = new ArrayList();
		
		list2.add(5);
		list2.add(3);
		list2.add(1);
		list2.add(2);
		
//		System.out.println(list2);
		
//		int[] a = Arrays.stream(list).mapToInt(Integer::intValue).toArray();
		

	}

}
