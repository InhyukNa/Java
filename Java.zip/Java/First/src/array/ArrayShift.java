package array;

public class ArrayShift {

	public static void main(String[] args) {

		int[] a = {10,20,30,40,50,60,70,80};
		
		for(int i : a) {
			System.out.print(i + "\t");
		}
		
		for(int i = 6; i >=0; --i) {
			a[i+1] = a[i];
		}
		
		for(int i : a) {
			System.out.print(i + "\t");
		}
	}

}
