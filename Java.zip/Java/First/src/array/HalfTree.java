package array;

public class HalfTree {

	public static void main(String[] args) {
		
		int a = 10;
		int b = 10;
		int c = 0;
		
		for(int lineNo = 0; lineNo <= a; lineNo++) {
			for(int spaceNo = 0; spaceNo <= b; spaceNo++) {
				System.out.print(" ");
			}
			for(int starNo = 0; starNo <= c; starNo++) {
				System.out.print("*");
			}
			b--;
			c++;
			System.out.println();
		}

	}

}
