package array;

public class ChangeRow {

	public static void main(String[] args) {
		
		int[][] square_matrix1 = new int[5][5];
		int[][] square_matrix2 = new int[5][5];
		int count_value = 0;
		
		for(int i = 0; i < 5; ++i) {
			for(int j = 0; j < 5; ++j) {
				square_matrix1[i][j] = ++count_value;
			}
		}
		
		for(int i = 0; i < 5; ++i) {
			for(int j = 0; j < 5; ++j) {
				System.out.print(square_matrix1[i][j] + "\t");
			}
			System.out.println();
		}
		
		for(int i = 0; i < 5; ++i) {
			for(int j = 0; j < 5; ++j) {
				square_matrix2[j][4-i] = square_matrix1[i][j];
			}
		}
		System.out.println("\r\n");
		for(int i = 0; i < 5; ++i) {
			for(int j = 0; j < 5; ++j) {
				System.out.print(square_matrix2[i][j] + "\t");
			}
			System.out.println();
		}
		
	}

}