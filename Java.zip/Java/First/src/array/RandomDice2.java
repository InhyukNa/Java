package array;

public class RandomDice2 {

	public static void main(String[] args) {
		
//		for(int i = 0; i < 1000; i++) {
//			System.out.println((int)((Math.random() * 10) % 6 + 1));
//		}
//		
		int[] dice_numbers = new int[1000];
		for(int i = 0; i < dice_numbers.length; ++i) {
			dice_numbers[i] = (int)((Math.random() * 10) % 6 + 1);
		}
		for(int i : dice_numbers) {
			System.out.printf("%s \t", i);
		}
		System.out.println();
		
		int one = 0;
		int two = 0;
		int three = 0;
		int four = 0;
		int five = 0;
		int six = 0;
		int zero = 0;
		
		char[][] graph = new char[1000][7];
		for(int i = 0; i < dice_numbers.length; ++i) {
			switch(dice_numbers[i]) {
			case 1:
				++one;
				graph[dice_numbers.length - one][1] = '*';
				break;
			case 2:
				++two;
				graph[dice_numbers.length - two][2] = '*';
				break;
			case 3:
				++three;
				graph[dice_numbers.length - three][3] = '*';
				break;
			case 4:
				++four;
				graph[dice_numbers.length - four][4] = '*';
				break;
			case 5:
				++five;
				graph[dice_numbers.length - five][5] = '*';
				break;
			case 6:
				++six;
				graph[dice_numbers.length - six][6] = '*';
				break;
			default:
				++zero;
				graph[dice_numbers.length - zero][0] = '*';
				break;
			}
		}
		
		for(int i = 0; i < 1000; ++i) {
			for(int j = 0; j < 7; ++j) {
				System.out.printf("%s \t", graph[i][j]);
			}
			System.out.println();
		}
		
		/**
		 * 10�з�
		 */
		int countOfZeros = (int)zero / 10;
		int countOfOnes = (int)one / 10;
		int countOfTwos = (int)two / 10;
		int countOfThrees = (int)three / 10;
		int countOfFours = (int)four / 10;
		int countOfFives = (int)five / 10;
		int countOfSixes = (int)six / 10;
		
		char[][] graph_by_perdecage = new char[100][7];
		for(int i = graph_by_perdecage.length - 1; i >= 0; --i) {
			for(int j = 0; j < graph_by_perdecage[0].length; ++j) {
				if(j == 0) {
					if(countOfZeros != 0) {
						graph_by_perdecage[i][j] = '*';
						--countOfZeros;
					}
				} else if(j == 1) {
					if(countOfOnes != 0) {
						graph_by_perdecage[i][j] = '*';
						--countOfOnes;	
						}
					} else if(j == 2) {
						if(countOfTwos != 0) {
							graph_by_perdecage[i][j] = '*';
							--countOfTwos;	
							}
						}
					else if(j == 3) {
						if(countOfThrees != 0) {
							graph_by_perdecage[i][j] = '*';
							--countOfThrees;	
							}
						}
					else if(j == 4) {
						if(countOfFours != 0) {
							graph_by_perdecage[i][j] = '*';
							--countOfFours;	
							}
						}
					else if(j == 5) {
						if(countOfFives != 0) {
							graph_by_perdecage[i][j] = '*';
							--countOfFives;	
							}
						}
					else if(j == 6) {
						if(countOfSixes != 0) {
							graph_by_perdecage[i][j] = '*';
							--countOfSixes;	
							}
						}
			}
			
			}
		for(char[] i2 : graph_by_perdecage) {
			for(char j2 : i2) {
				System.out.printf("%s \t", j2);
			}
			System.out.println();
		}

	}

}
