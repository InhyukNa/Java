package array;

public class ArrayTest {

	public static void main(String[] args) {
		
		int[] num = new int[] {1,2,3,4,5,6,7,8,9,10};
		
		for(int i = 0; i < num.length; i++) {
			System.out.println(num[i]);
		}
		
		String[] a = new String[3];
		for(int b = 0; b < 3; b++) {
			a[b] = "�ȳ�";	
		}

		System.out.println(a[0]+" , " +a[1]+" , "+a[2]);
	}

}
