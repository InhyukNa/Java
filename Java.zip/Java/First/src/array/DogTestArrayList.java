package array;

import java.util.ArrayList;

public class DogTestArrayList {

	public static void main(String[] args) {

		ArrayList<Dog> dogList = new ArrayList<Dog>();
		dogList.add(new Dog("a", "�׸���"));
		dogList.add(new Dog("b", "�㽺Ű"));
		dogList.add(new Dog("c", "ġ�Ϳ�"));
		dogList.add(new Dog("d", "��Ʈ����"));
		dogList.add(new Dog("e", "Ǫ��"));
		
		for(int i =0; i<dogList.size(); i++) {
			System.out.println(dogList.get(i).showDogInfo());
		}
	}

}
