package array;

public class MoveArray {

	public static void main(String[] args) {
		
		int[] moveArray = new int[] {10,20,30,40,50,60,70,80};
		
		int i = 7;
		if(i == 7) {	
			System.out.print(moveArray[i] + " ");
			i = 0;
			for(i = 0; i < (moveArray.length - 1); i++) {
				System.out.print(moveArray[i] + " ");
			}
		}
	}

}
