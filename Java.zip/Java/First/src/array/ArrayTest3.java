package array;

public class ArrayTest3 {

	public static void main(String[] args) {
		
		double[] data = new double[5];
		int size = 0;
		
		data[0] = 10.0; size++;
		data[1] = 20.0; size++;
		data[2] = 30.0; size++;
		
		for(int i = 0; i < size; i++) {
			System.out.println(data[i]);
		}
		
		double[] data2 = new double[5];
		
		for(int i2 = 0; i2 < 3; i2++) {
			data2[i2] = 10 + 10 * i2;
			
			System.out.println(data2[i2]);
		}
		

	}

}
