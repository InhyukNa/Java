package array;
import java.util.Random;
import java.util.ArrayList;

public class RandomDice {

	public static void main(String[] args) {
		
		ArrayList list1 = new ArrayList();
		ArrayList list2 = new ArrayList();
		ArrayList list3 = new ArrayList();
		ArrayList list4 = new ArrayList();
		ArrayList list5 = new ArrayList();
		ArrayList list6 = new ArrayList();
		
		Random rd = new Random();
		
		for(int i = 0; i < 1000; i++) {
			int dice = rd.nextInt(6)+1;
			if(dice == 1) {
				list1.add(1);	
			}
			if(dice == 2) {
				list2.add(1);	
			}
			if(dice == 3) {
				list3.add(1);	
			}
			if(dice == 4) {
				list4.add(1);	
			}
			if(dice == 5) {
				list5.add(1);	
			}
			if(dice == 6) {
				list6.add(1);	
			}
		}

//		System.out.println(list1.size());
		System.out.print("1" + '\t');
		for(int a = 0; a < list1.size(); a++) {
			System.out.print("*"+"");
		}
		System.out.println();
		System.out.print("2" + '\t');
		for(int a = 0; a < list2.size(); a++) {
			System.out.print("*"+"");
		}
		System.out.println();
		System.out.print("3" + '\t');
		for(int a = 0; a < list3.size(); a++) {
			System.out.print("*"+"");
		}
		System.out.println();
		System.out.print("4" + '\t');
		for(int a = 0; a < list4.size(); a++) {
			System.out.print("*"+"");
		}
		System.out.println();
		System.out.print("5" + '\t');
		for(int a = 0; a < list5.size(); a++) {
			System.out.print("*"+"");
		}
		System.out.println();
		System.out.print("6" + '\t');
		for(int a = 0; a < list6.size(); a++) {
			System.out.print("*"+"");
		}
	}

}
