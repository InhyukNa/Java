package collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class MemberListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Member> member = new ArrayList<>();
		member.add(new Member(1, "Karl"));
		member.add(new Member(2, "Brian"));
		Iterator<Member> iterator = member.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next().getMemberName());
		}
		
		List<String> myList = new LinkedList<>();
		myList = new ArrayList<String>();
	}

}
