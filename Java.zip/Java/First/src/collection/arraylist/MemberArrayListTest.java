package collection.arraylist;

import collection.Member;

public class MemberArrayListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MemberArrayList memberArrayList = new MemberArrayList();
		Member member1 = new Member(1001, "Rayan");
		Member member2 = new Member(1002, "Cherki");
		Member member3 = new Member(1003, "De jong");
		Member member4 = new Member(1004, "De ligt");
		
		memberArrayList.addMember(member1);
		memberArrayList.addMember(member2);
		memberArrayList.addMember(member3);
		memberArrayList.addMember(member4);
		
		memberArrayList.showAllMember();
		
		memberArrayList.removeMember(member1.getMemberID());
		memberArrayList.showAllMember();
		
		Member member5 = new Member(1005, "Lee");
		memberArrayList.insertMember(member5, 3);
		
		memberArrayList.showAllMember();
		
	}

}
