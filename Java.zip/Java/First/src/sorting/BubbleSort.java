package sorting;

public class BubbleSort implements Sort {

	@Override
	public void ascending(int[] arr) {
		
		System.out.println("BubbleSort ascending");
		
		int  i, j, temp;

		  for(i=arr.length-1; i>0; i--){
		    
		    for(j=0; j<i; j++){
		      
		      if(arr[j]<arr[j+1]){
		        temp = arr[j];
		        arr[j] = arr[j+1];
		        arr[j+1] = temp;
		      }
		    }
		  }
		  
		  for(i=arr.length-1; i>=0; i--){
			    System.out.printf("%d\t", arr[i]);
			  }
		  
		  System.out.println();
		
	}

	@Override
	public void descending(int[] arr) {

		System.out.println("BubbleSort descending");
		
		int  i, j, temp;

		  for(i=arr.length-1; i>0; i--){
		    
		    for(j=0; j<i; j++){
		      
		      if(arr[j]<arr[j+1]){
		        temp = arr[j];
		        arr[j] = arr[j+1];
		        arr[j+1] = temp;
		      }
		    }
		  }
		  
		  for(i=0; i<arr.length; i++){
			    System.out.printf("%d\t", arr[i]);
			  }
		  
		  System.out.println();
		
	}

	@Override
	public void description() {
		
		Sort.super.description();
		System.out.println("BubbleSort�Դϴ�");
		
	}
	
}
