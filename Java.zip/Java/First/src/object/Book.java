package object;

public class Book {

	@Override
	public String toString() {

		return bookTitle + ", " + bookNumber;
		
	}

	int bookNumber;
	String bookTitle;
	
	Book(int bookNumber, String bookTitle) {
		this.bookNumber = bookNumber;
		this.bookTitle = bookTitle;
		
	}
	
}
