package object;

public class MyDate {

	int day;
	int month;
	int year;
	
	public MyDate(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}

	@Override
	public boolean equals(Object obj) {
		
		if(obj instanceof MyDate) {
			MyDate rightSide = (MyDate)obj;
			if(this.day == rightSide.day && this.month == rightSide.month && this.year == rightSide.year)
				return true;
			else return false;
		}
		else return false;
//		return super.equals(obj);
	}
	
	
}
