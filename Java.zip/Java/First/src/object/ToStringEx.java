package object;

public class ToStringEx {

	public static void main(String[] args) {

		Book book1 = new Book(200, "����");
		
		System.out.println(book1);
		System.out.println(book1.toString());
		
	}

}
