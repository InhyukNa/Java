package staticex;

public class StudentTest6 {

	public static void main(String[] args) {
		
		Student3 studentLee = new Student3();
		studentLee.setStudentName("�̰���");
		System.out.println(Student3.getSerialNum());
		System.out.println(studentLee.studentName + " �й�:" + studentLee.studentID
				+ " / �л� ī�� ��ȣ:" + studentLee.cardNo);
		
		Student3 studentSon = new Student3();
		studentSon.setStudentName("�����");
		System.out.println(Student3.getSerialNum());
		System.out.println(studentSon.studentName + " �й�:" + studentSon.studentID
				+ " / �л� ī�� ��ȣ:" + studentSon.cardNo);
	}

}
