package loopexample;

public class For9_9 {

	public static void main(String[] args) {
		
		int z = 1;
	    int zz = 1;
	    int sum1 = 0;

	    while (z <= 9 && zz <= 9) {
	    	
	        sum1 = z * zz;
	        z++;
	        
	        System.out.println(zz+"x"+z+"="+sum1);
	        
	        if (z == 9) {
	        	
	            z = 1;
	            zz = zz+1;
	            
	        }
	    }
	    
//	    int hii = 0;
//	    for (int x=0; x <= 9; x++) {
//	    	int y = (x+1);
//	    	hii = x * y;
//	    	x++;
//	    	System.out.println(hii);
//	    }
	         

	}

}
