package loopexample;

public class Tree {

	public static void main(String[] args) {
		
		int a = 4;
		int b = 3;
		int c = 1;
		
		for (int x = 0; x < a; x++) {
			for (int y = 0; y < b; y++) {
				System.out.printf(" ");
			}
			
			for (int y = 0; y < c; y++) {
				System.out.printf("*");
			}
			
			for (int y = 0; y < b; y++) {
				System.out.printf(" ");
			}
			b--;
			c += 2;
			System.out.println();
		}
		
	}

}
