package loopexample;

public class WhileExample1 {

	public static void main(String[] args) {
		
		int num = 1;
		int sum = 0;
		
		while (num <= 10) {
			sum += num;
			num++;
		}
		System.out.println("1���� 10������ ���� " + sum + "�Դϴ�.");
		
		System.out.print("\n");
		
		int no = 1;
		int sumNo = 0;
		
		while(no <= 10) {
			int no2 = no * no;
			sumNo += no2;
			no++;
		}
		System.out.println(sumNo);

	}

}
