//package loopexample;
//
//public class InputExample {
//
//	public static void main(String[] args) throws Exception{
//		
//		System.out.print("�ѱ��� �Է� > ");
//		byte[] str_buffer = new byte[1024];
//		int value = System.in.read(str_buffer);
//		String str = new String(str_buffer);
//		System.out.println(str);
//	}
//
//}
