package stream;

import java.util.function.BinaryOperator;

public class CalcRunnable {
	public static void main(String[] args) {
		BinaryOperator<Integer> binaryOperator = (num1,num2) -> {
	    	return num1 + num2;
	    };
	    
	    System.out.println(binaryOperator.apply(1, 2));
	}
}
