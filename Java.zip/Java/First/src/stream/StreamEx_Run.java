package stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

public class StreamEx_Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] array1 = {1,2,3,4,5,6,7};
		for(int i : array1) {
			System.out.println(i);
		}
		
		System.out.println("\r\n");
//		Arrays.stream(array1).filter(s -> s > 3).forEach(it -> System.out.println(it));
		Arrays
		.stream(array1)
		.filter(s -> s > 3)
		.forEach(it -> System.out.println(it));
		
		List<String> list = Arrays.asList("ȫ�浿", "�ſ��", "���ڹ�");
		Stream<String> stream = list.stream();
		Long count_number = list.stream().count();
		Long count_number2 = stream.count();
		System.out.println(count_number);
		
		ArrayList<String> list2 = new ArrayList();
		Iterator<String> iterator = list2.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}

}
