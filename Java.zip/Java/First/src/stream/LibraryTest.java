package stream;

import java.util.ArrayList;
import java.util.List;

public class LibraryTest {

	public static void main(String[] args) {
		List<Book> bookList = new ArrayList<>();
		
		bookList.add(new Book("�ڹ�", 25000));
		bookList.add(new Book("���̽�", 15000));
		bookList.add(new Book("�ȵ���̵�", 3000));
		
		int bookPrice = bookList.stream()
				.mapToInt(c -> c.getPrice())
				.sum();
		System.out.println(bookPrice);
		
		System.out.println();
		
		bookList.stream()
		.map(c -> c.getName())
		.sorted()
		.forEach(s -> System.out.println(s));
	}
	
}
