package stream;

public class Member implements Comparable<Member>{

	private Integer ID;
	private String name;
	@Override
	public int compareTo(Member o) {
		// TODO Auto-generated method stub
		if(this.ID > o.ID) return 1;
		else if(this.ID == o.ID) return 0;
		else return -1;
	}
	public Integer getID() {
		return ID;
	}
	public void setID(Integer iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
