package stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.function.BinaryOperator;
import java.util.stream.Stream;

public class IntArrayTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = {1,2,3,4,5};
		
		int sumVal = Arrays.stream(arr).sum();
		int count = (int)Arrays.stream(arr).count();
		
		int total = 0;
		for(int i : arr) {
			total += i;
		}
		
		System.out.println(sumVal);
		System.out.println(count);
		System.out.println(total);
		System.out.println(Arrays.stream(arr).sum());
		Long countC = Arrays.stream(arr).count();
		System.out.println(countC);
		System.out.println(Arrays.stream(arr).max().orElse(0));
		System.out.println(Arrays.stream(arr).average().orElse(0.0));
		
		ArrayList<String> list = new ArrayList<String>();
		list.add(new String("Thomas"));
		list.add("Edward");
		list.add(new String("Felix"));
		list.stream().filter(it -> it == "Edward").forEach(it -> System.out.println("Edward"));
		
		Stream<String> stream = list.stream();
		stream.filter(it -> it == "Felix").forEach(it -> System.out.println("Felix"));
		
		BinaryOperator<String> binary = (t,v) -> t + v;
		stream.reduce("", binary);
	}

}
