package stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ReduceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> greetings = Arrays.asList("�ȳ��ϼ���~~~", "hello", "Good Morning", "�ݰ����ϴ�^^");
		
		String result = greetings.stream().reduce("0", (s1, s2) -> {
			if(s1.getBytes().length >= s2.getBytes().length) return s1;
			else return s2;
		});
		
		System.out.println(result);
	}

}
