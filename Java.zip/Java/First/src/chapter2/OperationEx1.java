package chapter2;

public class OperationEx1 {

	public static void main(String[] args) {
		
		int mathScore = 90;
		int engScore = 70;
		
		int totalScore = mathScore + engScore;
		System.out.println(totalScore);
		
		double avgScore = totalScore / 2.0;
		System.out.println(avgScore);
		
		System.out.print('\n');
		
		// 88p. Q1
		int myAge = 23;
		int teacherAge = 38;
		
		boolean value = (myAge > 25);
		System.out.println(value);
		
		System.out.println(myAge <= 25);
		System.out.println(myAge == teacherAge);
		
		char ch = (myAge > teacherAge) ? 'T' : 'F';
		
		System.out.println(ch);
		
		System.out.print('\n');
		
		// Q2
		int num;
		num = -5 + 3 * 10 / 2;
		System.out.println(num);
		
		System.out.print('\n');
		
		// Q3
		int numN = 10;
		
		System.out.println(numN);
		System.out.println(numN++);
		System.out.println(numN);
		System.out.println(--numN);
		
		System.out.print('\n');
		
		// Q4
		int num1 = 10;
		int num2 = 20;
		boolean result;
		
		result = ((num1 > 10) && (num2 > 10));
		System.out.println(result);
		result = ((num1 > 10) || (num2 > 10));
		System.out.println(result);
		System.out.println(!result);
		
		System.out.print('\n');
		
		// Q5
		int num3 = 2;
		int num4 = 10;
		
		System.out.println(num3 & num4);
		System.out.println(num3 | num4);
		System.out.println(num3 ^ num4);
		System.out.println(~num3);
		
		System.out.print('\n');
		
		// Q6
		int num5 = 8;
		
		System.out.println(num5 += 10);
		System.out.println(num5 -= 10);
		System.out.println(num5 >>= 2);
		
		System.out.print('\n');
		
		// Q7
		int num6 = 10;
		int num7 =20;
		
		int resultR = (num6 >= 10) ? num7 + 10 : num7 - 10;
		System.out.println(resultR);
		
	}

}
