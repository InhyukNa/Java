package chapter2;

public class OperationEx4 {

	public static void main(String[] args) {
		
		int fatherAge = 45;
		int motherAge = 47;
		
		char ch = (fatherAge > motherAge) ? 'T' : 'F';
		
		boolean ch2 = (fatherAge < motherAge) ? true : false;
		
		System.out.println(ch);
		System.out.println(ch2);

	}

}
