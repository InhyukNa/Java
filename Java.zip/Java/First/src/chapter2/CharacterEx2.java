package chapter2;

public class CharacterEx2 {

	public static void main(String[] args) {
		
		char ch1 = '��';
		char ch2 = '\uD55C';
		
		System.out.println(ch1);
		System.out.println(ch2);
		

	}

}
