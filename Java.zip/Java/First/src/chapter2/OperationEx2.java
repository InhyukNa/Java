package chapter2;

public class OperationEx2 {

	public static void main(String[] args) {
		
		int gameScore = 150;
		
		int lastScore1 = ++gameScore;
		System.out.println(lastScore1);
		
		int lastScore2 = --gameScore;
		System.out.println(lastScore2);
		
//		int value = 0;
//		int result = value++;
//		System.out.println(result);
//		System.out.println(++value);
//		System.out.println(value++);
		
		for(int num = 0; num < 10; ++num) {
			System.out.println("Hello");
		}
		
		for(int num2 = 0; num2 < 10; num2++) {
			System.out.println("Hi");
		}
		
	}

}
