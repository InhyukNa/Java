package chapter2;

public class ExpliocitConversion {

	public static void main(String[] args) {
		
		double dNum1 = 1.2;
		float fNum2 = 0.9F;
		
		int iNum3 = (int)dNum1 + (int)fNum2;
		int iNum4 = (int)(dNum1 + fNum2);
		System.out.println(iNum3);
		System.out.println(iNum4);

		System.out.print("\n");
		
		// 69p. Q04
		int a = 10;
		double b = 2.0;
		int cPlus = (int)(a + b);
		int cMinus = (int)(a - b);
		int cTime = (int)(a * b);
		int cDivide = (int)(a / b);
		System.out.println(cPlus);
		System.out.println(cMinus);
		System.out.println(cTime);
		System.out.println(cDivide);
		
	}

}
