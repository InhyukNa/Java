package abstractex;

public class RunnableClass {

	public static void main(String[] args) {

		Computer desktop = new Desktop();
		desktop.display();
		desktop = new MyNoteBook();
		desktop.display();
		
	}

}
