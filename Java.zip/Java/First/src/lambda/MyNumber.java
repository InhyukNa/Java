package lambda;
@FunctionalInterface
public interface MyNumber {

	int getMax(int num1, int num2);
//	int add(int num1, int num2);
	
}
