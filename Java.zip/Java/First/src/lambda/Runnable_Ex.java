package lambda;

public class Runnable_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Runnable run = () -> {
			for(int i = 0; i < 10; ++i) {
				System.out.println(i);
				try {
					Thread.sleep(1000);
				} catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		};
		
		Thread thread = new Thread(run);
		thread.start();
		for(int i = 10; i > 0; --i) {
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}

}
