package lambda;

import java.util.function.Consumer;

public class Consumer_Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Consumer<Member> consumer1 = (_s) -> {
			System.out.println(_s.getName());
		};
		
		Consumer<Member> consumer2 = (_s) -> {
			System.out.println(_s.getID());
		};
		
		Consumer<Member> consumer2_1 = consumer1.andThen(consumer2);
		consumer2_1.accept(new Member("Karl", "1234"));
	}

}
