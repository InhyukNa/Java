package lambda;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public class ConsumerRunnable {
	public static void main(String[] args) {
		Consumer<String> consumer = t -> System.out.println(t+" java");
	    consumer.accept("Hello");
	    BiConsumer<String,String> biconsumer = (t,u) -> System.out.println(t+""+u);
	    biconsumer.accept("hello", "java");
	    BiConsumer<Integer, Integer> biconsumer2 = (t,u) -> System.out.println(t+u);
	    biconsumer2.accept(100,  500);
	    
	    Supplier<String> supplier = () -> "Hello Java 8";
	    System.out.println(supplier.get());
	    Supplier<Integer> supplier2 = () -> {
	    	int random_number = (int)(Math.random() * 6) + 1;
	    	return random_number;
	    };
	    System.out.println("�ֻ��� ��ȣ�� " + supplier2.get());
	    
	    Function<String, String> function = (_s) -> "Hello" + _s;
	    System.out.println(function.apply(" Java 8"));
	    
	    BiFunction<Integer, Integer, Integer> bifunction = (t,u) -> {
	    	Integer sum = t + u;
	    	return sum;
	    };
	    System.out.println(bifunction.apply(100, 500));
	    
	    BiFunction<Integer, Double, Double> bifunction2 = (t,u) -> {
	    	Double sum = (Double)(t + u);
	    	return sum;
	    };
	    System.out.println(bifunction2.apply(100, 500.0));
	    
	    UnaryOperator<Integer> unaryoperator = (_t) -> {
	    	return _t + 500;
	    };
	    System.out.println(unaryoperator.apply(100));
	    
	    BinaryOperator<String> binaryOperator = (t,u) -> {
	    	return t + u;
	    };
	    System.out.println(binaryOperator.apply("Hello", " Java 8"));
	    
	    System.out.println(function1.apply(100_000));
	    
	    Predicate<Integer> predicate = (t) -> {
	    	return t > 10;
	    };
	    System.out.println(predicate.test(100));
	    
	    BiPredicate<Double, Double> bipredicate = (t,u) -> {
	    	return t > u;
	    };
	    System.out.println(bipredicate.test(10.0, 1000.0));
	}
	private static Function<Integer, String> function1 = (t) -> {
		return t.toString();
	};
}
